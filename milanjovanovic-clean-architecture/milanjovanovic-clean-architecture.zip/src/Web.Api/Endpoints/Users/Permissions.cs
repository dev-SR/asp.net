﻿namespace Web.Api.Endpoints.Users;

internal static class Permissions
{
    internal const string UsersAccess = "users:access";
}
